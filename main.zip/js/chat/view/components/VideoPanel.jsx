import React from 'react';

class VideoPanel extends React.Component {
    render() {
        return (
            <div class="container">
                <video id="video"/>
                <video id="selfVideo" style={{height: '50px', width: '50px'}}/>
            </div>
        );
    }
}
export default VideoPanel;