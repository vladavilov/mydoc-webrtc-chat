import React from 'react';

class StatusPanel extends React.Component {

    constructor(props) {
        super(props);

        this.statusToStyle = {
            OFFLINE: 'btn-danger',
            ONLINE: 'btn-success',
            CONNECTING: 'btn-warning'
        };

        this.statusToText = {
            OFFLINE: 'Offline',
            ONLINE: 'Online',
            CONNECTING: 'Is connecting...'
        };

        this.state = {
            onlineStatus: 'OFFLINE'
        }
    }

    render() {
        return (
            <div class="row">
                <button type="button"
                        class={'btn ' + this.statusToStyle[this.state.onlineStatus]}>{this.statusToText[this.state.onlineStatus]}</button>
                <h4>
                    <small>You've logged in as</small>
                    {this.props.currentUser}
                </h4>
            </div>
        );
    }
}
export default StatusPanel;