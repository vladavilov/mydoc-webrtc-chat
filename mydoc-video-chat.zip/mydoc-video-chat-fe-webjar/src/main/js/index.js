import React from "react";
import ReactDOM from "react-dom";
import Chat from "./chat/Chat";

const render = Component => {
    ReactDOM.render(
        <Component currentUser={isPatient ? patientName : docName}/>,
        document.getElementById('chat'),
    );
};

render(Chat);