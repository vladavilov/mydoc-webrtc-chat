import React from 'react';

class Message extends React.Component {

    constructor(props) {
        super(props);

        this.message = props.message;
    }

    render() {
        return <li className={`message ${this.message.isFromCurrentUser ? "right" : "left"}`}>
            <img src={this.message.avatar} alt={`Sender's pic`} />
            {this.message.text}
        </li>;
    }
}
export default Message;