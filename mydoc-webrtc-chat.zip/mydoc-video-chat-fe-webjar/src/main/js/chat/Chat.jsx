import React from 'react';
import MessagesPanel from './view/components/MessagesPanel';
import VideoPanel from './view/components/VideoPanel';
import StatusPanel from './view/components/StatusPanel';

class Chat extends React.Component {
    render() {
        return (
            <div>
                <StatusPanel/>
            </div>
            <div>
                <MessagesPanel />
                <VideoPanel />
            </div>
        );
    }
}
export default Chat;