import React from 'react';

class StatusPanel extends React.Component {
    render() {
        return (
            <div>
                Hello World!!!
            </div>
        );
    }
}
export default StatusPanel;