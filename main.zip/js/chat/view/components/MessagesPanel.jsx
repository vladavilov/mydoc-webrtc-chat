import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
// import Conversation from 'chat-template/dist/Conversation';
import './MessagesPanel.css';

class MessagesPanel extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            messages: [{
                message: 'How do I use this messaging app?',
                from: 'right',
                backColor: '#3d83fa',
                textColor: "white",
                avatar: 'https://www.seeklogo.net/wp-content/uploads/2015/09/google-plus-new-icon-logo.png'
            }, {
                message: 'How do I use this messaging app?',
                from: 'left',
                backColor: 'white',
                textColor: "black",
                avatar: 'https://www.seeklogo.net/wp-content/uploads/2015/09/google-plus-new-icon-logo.png'
            }]
        };

        this.submitMessage = this.submitMessage.bind(this);
    }

    componentDidMount() {
        this.scrollToBottom();
    }

    componentDidUpdate() {
        this.scrollToBottom();
    }

    scrollToBottom() {
        // const conversationPanel = ReactDOM.findDOMNode(this.refs.messages);
        // conversationPanel.scrollTop = conversationPanel.scrollHeight;
    }

    eraseMessage() {
        this.messageText().value = "";
    }

    messageText() {
        return ReactDOM.findDOMNode(this.refs.messageText);
    }

    submitMessage(event) {
        event.preventDefault();

        this.setState({
            messages: this.state.messages.concat([{
                message: <p>{this.props.currentUser + ':' + this.messageText().value}</p>,
                from: 'left',
                backColor: 'white',
                textColor: "black",
                avatar: 'https://www.seeklogo.net/wp-content/uploads/2015/09/google-plus-new-icon-logo.png'
            }])
        }, () => {
            this.eraseMessage();
        });
    }

    render() {
        const {messages} = this.state;
        //<Conversation ref="conversationPanel" messages={messages} height isScrollable/>
        return (
            <div className="MessagesPanel">

                <form className="input" onSubmit={(event) => this.submitMessage(event)}>
                    <input ref="messageText" type="text"/>
                    <input type="submit" value="Send" class="btn btn-primary"/>
                </form>
            </div>
        );
    }
}


MessagesPanel.propTypes = {
    currentUser: PropTypes.string,
};
MessagesPanel.defaultProps = {
    currentUser: 'N/A',
};
export default MessagesPanel;