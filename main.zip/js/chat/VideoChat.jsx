import React from 'react';
import PropTypes from 'prop-types';
import MessagesPanel from './view/components/MessagesPanel.jsx';
import VideoPanel from './view/components/VideoPanel.jsx';
import StatusPanel from './view/components/StatusPanel.jsx';
import './../css/bootstrap.min.css'

class VideoChat extends React.Component {

    render() {
        return (
            <div class="container-fluid">
                <div class="col-xs-12">
                    <StatusPanel currentUser={this.props.currentUser}/>
                </div>
                <div class="row">
                    <div class="col-xs-5">
                        <MessagesPanel currentUser={this.props.currentUser}/>
                    </div>
                    <div class="col-xs-7">
                        <VideoPanel/>
                    </div>
                </div>
            </div>
        );
    }
}

VideoChat.propTypes = {
    currentUser: PropTypes.string,
};
VideoChat.defaultProps = {
    currentUser: 'N/A',
};
export default VideoChat;