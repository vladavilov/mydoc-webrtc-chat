import React from 'react';

class VideoPanel extends React.Component {
    render() {
        return (
            <div>
                Hello World!!!
            </div>
        );
    }
}
export default VideoPanel;