package com.web.mydoc.video.chat.room.admin.link;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoomLinkContainer {

    private String patientLink;
    private String docLink;
}
